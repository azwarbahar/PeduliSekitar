<?php 
define('host', 'localhost');
define('user', 'root');
define('db', 'db_peduli_sekitar');

$conn = mysqli_connect(host, user, "", db) or die('Unable to Connect');
?>