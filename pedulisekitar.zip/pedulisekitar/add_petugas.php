<?php
header("Content-Type: application/json; charset=UTF-8");
require_once 'connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $nama_petugas = $_POST['nama_petugas'];
    $profesi = $_POST['profesi'];
    $username = $_POST['username'];
    $password = $_POST['password'];
   
    $query = "INSERT INTO tb_petugas values('','$nama_petugas','$profesi','$username','$password')";

    $exeQuery =  mysqli_query($conn, $query);
    echo ($exeQuery) ? json_encode(array('kode' =>1, 'pesan' => 'Berhasil Menambahkan Data'
    )) : json_encode(array('kode' => 2, 'pesan' => 'Data Gagal Ditambahkan'));
} else {
    echo json_encode(array(' kode ' =>101, ' pesan ' => ' Request Tidak Valid' ));
}
?>