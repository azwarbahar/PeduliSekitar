<?php 

header("Content-Type: application/json; charset=UTF-8");

require_once 'connect.php';

$query = "SELECT * FROM tb_laporan ORDER BY id_laporan ";
$result = mysqli_query($conn, $query);

$array = array();

$server_name = $_SERVER['SERVER_ADDR'];
$ip_address = "192.168.43.188";

while( $row = mysqli_fetch_assoc($result) ){

    array_push($array, 
    array(
        'id'        =>$row['id_laporan'], 
        'name'      =>$row['nama_lengkap'], 
        'telpon'   =>$row['telpon'],
        'deskripsi'     =>$row['deskripsi'],
        'tanggal'    =>$row['tanggal'],
        'jam'     =>$row['jam'],
        'alamat'    =>$row['alamat'],
        'latitude'     =>$row['latitude'],
        'longitude'    =>$row['longitude'],
        'picture'   =>"http://$ip_address" . $row['path'],
        'status'      =>$row['status']) 
    );
}

echo ($result) ?
json_encode(array("kode" => 1, "resultDataLaporan" => $array)) :
json_encode(array("kode" => 0, "pesan" => "data tidak ditemukan"));

mysqli_close($conn);

?>