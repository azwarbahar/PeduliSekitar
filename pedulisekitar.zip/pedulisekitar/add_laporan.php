<?php 

require_once 'connect.php';

$nama_lengkap   = $_POST["nama_lengkap"];
$telpon         = $_POST["telpon"];
$deskripsi      = $_POST["deskripsi"];
$tanggal        = $_POST["tanggal"];
$jam            = $_POST["jam"];
$alamat         = $_POST["alamat"];
$latitude       = $_POST["latitude"];
$longitude      = $_POST["longitude"];
$status         = $_POST["status"];
$image          = $_POST["image"];

$query = "INSERT INTO tb_laporan (nama_lengkap,telpon,deskripsi,tanggal,jam,alamat,latitude,longitude,status) value('$nama_lengkap','$telpon','$deskripsi', '$tanggal','$jam', '$alamat', '$latitude', '$longitude', '$status');";

        if ( mysqli_query($conn, $query) ){

            if ($image == null) {

                $finalPath = "/pedulisekitar/pet_logo.png"; 
                $result["value"] = "1";
                $result["message"] = "Success";
    
                echo json_encode($result);
                mysqli_close($conn);

            } else {

                $id = mysqli_insert_id($conn);
                $path = "pets_picture/$id.jpeg";
                $finalPath = "/pedulisekitar/".$path;

                $insert_picture = "UPDATE tb_laporan SET path='$finalPath' WHERE id_laporan='$id' ";
            
                if (mysqli_query($conn, $insert_picture)) {
            
                    if ( file_put_contents( $path, base64_decode($image) ) ) {
                        
                        $result["value"] = "1";
                        $result["message"] = "Success!";
            
                        echo json_encode($result);
                        mysqli_close($conn);
            
                    } else {
                        
                        $response["value"] = "0";
                        $response["message"] = "Error! ".mysqli_error($conn);
                        echo json_encode($response);

                        mysqli_close($conn);
                    }

                }
            }

        } 
        else {
            $response["value"] = "0";
            $response["message"] = "Error! ".mysqli_error($conn);
            echo json_encode($response);

            mysqli_close($conn);
        }


?>