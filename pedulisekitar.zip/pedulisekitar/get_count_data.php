<?php 
require_once 'connect.php';

$sql="SELECT *FROM tb_laporan ORDER BY id_laporan";

if ($result=mysqli_query($conn,$sql))
  {
  $rowcount=mysqli_num_rows($result);
  
  echo json_encode(array("kode"=>1,"value"=>$rowcount));
 
  }
mysqli_close($conn);

?>



