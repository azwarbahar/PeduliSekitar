<?php 
require_once 'connect.php';

 $username = $_GET["username"];
 $password = $_GET["password"];

 $query = "SELECT * FROM tb_petugas WHERE username='$username' AND username='$password'";

 $sql = mysqli_query($conn, $query);

 $ray = array();
 while ($row = mysqli_fetch_array($sql)) {
     array_push($ray, array(
         "id_petugas"=>$row['id_petugas'],
         "nama_petugas"=>$row['nama_petugas'],
         "profesi"=>$row['profesi'],
         "username"=>$row['username'],
         "password"=>$row['password']
     ));
 }

 echo json_encode($ray);
 mysqli_close($conn);

?>