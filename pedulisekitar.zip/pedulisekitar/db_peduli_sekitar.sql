-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 12 Bulan Mei 2020 pada 16.57
-- Versi server: 10.1.31-MariaDB
-- Versi PHP: 7.1.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_peduli_sekitar`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_laporan`
--

CREATE TABLE `tb_laporan` (
  `id_laporan` int(11) NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  `telpon` varchar(100) NOT NULL,
  `deskripsi` varchar(300) NOT NULL,
  `tanggal` varchar(100) NOT NULL,
  `jam` varchar(100) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `latitude` varchar(100) NOT NULL,
  `longitude` varchar(100) NOT NULL,
  `path` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_laporan`
--

INSERT INTO `tb_laporan` (`id_laporan`, `nama_lengkap`, `telpon`, `deskripsi`, `tanggal`, `jam`, `alamat`, `latitude`, `longitude`, `path`, `status`) VALUES
(1, 'iyam', '70894331989', 'banyak orang', 'Minggu, 10 Mei 2020', '23:04', 'Jl. Veteran Selatan No.306, Mamajang Dalam, Kec. Mamajang, Kota Makassar, Sulawesi Selatan 90135, In', '-5.162618604948516', '119.42132033407687', '/pedulisekitar/pets_picture/0.jpeg', '1'),
(2, 'iyafds', '70899599', 'banyak oranbfbf', 'Minggu, 10 Mei 2020', '23:06', 'Jl. Andi Djemma No.94f, Banta-Bantaeng, Kec. Rappocini, Kota Makassar, Sulawesi Selatan 90222, Indon', '-5.164976381569342', '119.42596692591907', '/pedulisekitar/pets_picture/2.jpeg', '0'),
(6, 'pampam', '0864325496', 'terjadi keramaian di suatu tempat. tolong di tindaki', 'Senin, 11 Mei 2020', '00:05', 'Jl. Sultan Alauddin No.311a, Gn. Sari, Kec. Rappocini, Kota Makassar, Sulawesi Selatan 90221, Indone', '-5.186422028706346', '119.44096416234972', '/pedulisekitar/pets_picture/6.jpeg', '1'),
(7, 'maulidani', '08796431254', 'sangat ramai', 'Senin, 11 Mei 2020', '00:23', 'Jl. Urip Sumoharjo No.44, Tello Baru, Kec. Panakkukang, Kota Makassar, Sulawesi Selatan 90233, Indon', '-5.1463119406853215', '119.46990888565777', '/pedulisekitar/pets_picture/7.jpeg', '0'),
(8, 'awal fikri', '085463216795', 'Tidak mau mendengar arahan pemerintah. Tolong di tindaki ', 'Senin, 11 Mei 2020', '01:12', 'Jl. Pd. Lestari No.BLOK.E, RT.001/RW.01, Parang Tambung, Kec. Tamalate, Kota Makassar, Sulawesi Sela', '-5.17944708090205', '119.42040871828793', '/pedulisekitar/pets_picture/8.jpeg', '1'),
(9, 'Farid', '08564325168', 'Banyak yang tidak mendengarkan himbauan pemerintah, keramaian terjadi di mana mana. tolong di tindaki', 'Senin, 11 Mei 2020', '16:41', 'Jl. Tamangapa Raya No.112, Bangkala, Kec. Manggala, Kota Makassar, Sulawesi Selatan 90235, Indonesia', '-5.175771754298851', '119.48151111602782', '/pedulisekitar/pets_picture/9.jpeg', '0'),
(11, 'test apk', '08794661', 'test aplikasi', 'Senin, 11 Mei 2020', '23:21', 'Unnamed Road, Benteng Somba Opu, Benteng Somba Opu, Kec. Barombong, Kabupaten Gowa, Sulawesi Selatan 90225, Indonesia', '-5.198349281275947', '119.40978180617094', '/pedulisekitar/pets_picture/11.jpeg', '0'),
(12, 'Ferdinan Sinaga', '087964531284', 'Ramai Main bola', 'Selasa, 12 Mei 2020', '01:36', 'Jl. Costa Verde No.3, Tj. Merdeka, Kec. Tamalate, Kota Makassar, Sulawesi Selatan 90225, Indonesia', '-5.184449324007945', '119.39040619879961', '/pedulisekitar/pets_picture/12.jpeg', '1'),
(13, 'nurdin', '078964315848', 'Buat test', 'Selasa, 12 Mei 2020', '14:36', 'Jl. Balla Lompoa, Kanjilo, Kec. Barombong, Kabupaten Gowa, Sulawesi Selatan 90225, Indonesia', '-5.219500307691606', '119.41949743777514', '/pedulisekitar/pets_picture/13.jpeg', '0'),
(14, 'Reemar', '089764352154', 'Buka puasa bersama', 'Selasa, 12 Mei 2020', '17:57', 'Jl. Usman Salengke No.108, Sungguminasa, Kec. Somba Opu, Kabupaten Gowa, Sulawesi Selatan 92111, Indonesia', '-5.20787262343326', '119.4547862559557', '/pedulisekitar/pets_picture/14.jpeg', '0');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_petugas`
--

CREATE TABLE `tb_petugas` (
  `id_petugas` int(11) NOT NULL,
  `nama_petugas` varchar(100) NOT NULL,
  `profesi` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_petugas`
--

INSERT INTO `tb_petugas` (`id_petugas`, `nama_petugas`, `profesi`, `username`, `password`) VALUES
(1, 'Aril Noah', 'Polisi', 'polisi', 'polisi'),
(2, 'Atta Halilintar', 'Satpol PP', 'satpol', 'satpol'),
(3, 'Al Gazali', 'TNI', 'tni', 'tni'),
(6, 'Charles', 'Relawan', 'relawan', 'relawan'),
(10, 'dhsj', 'ndsmnsdm', 'tentarafjkn', 'tentarafd'),
(11, 'baco', 'Relawan', 'relawan', 'relawan'),
(13, 'Pasha Ungu', 'Satpam', 'satpam', 'satpam'),
(14, 'Afgan', 'Polri', 'polri', 'polri');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tb_laporan`
--
ALTER TABLE `tb_laporan`
  ADD PRIMARY KEY (`id_laporan`);

--
-- Indeks untuk tabel `tb_petugas`
--
ALTER TABLE `tb_petugas`
  ADD PRIMARY KEY (`id_petugas`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tb_laporan`
--
ALTER TABLE `tb_laporan`
  MODIFY `id_laporan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT untuk tabel `tb_petugas`
--
ALTER TABLE `tb_petugas`
  MODIFY `id_petugas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
