<?php 

header("Content-Type: application/json; charset=UTF-8");

require_once 'connect.php';

 $id_laporan = $_GET["id_laporan"];

 $query = "SELECT * FROM tb_laporan WHERE id_laporan='$id_laporan'";

 $sql = mysqli_query($conn, $query);
 
$server_name = $_SERVER['SERVER_ADDR'];
$ip_address = "192.168.43.188";

 $ray = array();
 while ($row = mysqli_fetch_array($sql)) {
     array_push($ray, array(
         "id"=>$row['id_laporan'],
         "name"=>$row['nama_lengkap'],
         "telpon"=>$row['telpon'],
         "deskripsi"=>$row['deskripsi'],
         "tanggal"=>$row['tanggal'],
         "jam"=>$row['jam'],
         "alamat"=>$row['alamat'],
         "latitude"=>$row['latitude'],
         "longitude"=>$row['longitude'],
         "picture"=>"http://$ip_address" . $row['path'],
         "status"=>$row['status'],
     ));
 }

 echo ($sql) ?
 json_encode(array("kode" => 1, "resultDataLaporan" => $ray)) :
 json_encode(array("kode" => 0, "pesan" => "data tidak ditemukan"));

//  echo json_encode($ray);
 mysqli_close($conn);

?>