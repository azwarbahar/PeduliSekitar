<?php 
require_once 'connect.php';
if($_SERVER['REQUEST_METHOD'] == 'POST')
{
    $id_laporan = $_POST['id_laporan'];
    $status = $_POST['status'];
    
   
    $query = "UPDATE tb_laporan SET status = '$status' WHERE id_laporan = '$id_laporan'";

    
$exeQuery =  mysqli_query($conn, $query);
echo ($exeQuery) ? json_encode(array('kode' =>1, 'pesan' => 'Berhasil Mengubah Data'
)) : json_encode(array('kode' => 2, 'pesan' => 'Data Gagal Diubah'));
} else {
echo json_encode(array(' kode ' =>101, ' pesan ' => ' Request Tidak Valid' ));
}

?>